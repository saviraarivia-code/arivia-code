ARIVIA SCHOOL WEBSITE

Semua file HTML dan logo sudah disatukan. Buka "frame arivia sekolah(1).html" di laptop. Untuk dibuka lewat HP dengan satu link, upload folder ini ke hosting seperti GitHub Pages atau Netlify.
